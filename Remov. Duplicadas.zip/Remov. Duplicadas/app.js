import fs from 'fs';
import readline from 'readline';
import path from 'path';
import chalk from 'chalk';

// Função para imprimir os créditos
// Função para imprimir os créditos
function printCredits() {
  console.log(chalk.blue(`

    █████▒█    ██   ██████  ██▓ ▒█████   ███▄    █     ▄████▄   ▒█████  ▓█████▄ ▓█████  ██▀███  
    ▓██   ▒ ██  ▓██▒▒██    ▒ ▓██▒▒██▒  ██▒ ██ ▀█   █    ▒██▀ ▀█  ▒██▒  ██▒▒██▀ ██▌▓█   ▀ ▓██ ▒ ██▒
    ▒████ ░▓██  ▒██░░ ▓██▄   ▒██▒▒██░  ██▒▓██  ▀█ ██▒   ▒▓█    ▄ ▒██░  ██▒░██   █▌▒███   ▓██ ░▄█ ▒
    ░▓█▒  ░▓▓█  ░██░  ▒   ██▒░██░▒██   ██░▓██▒  ▐▌██▒   ▒▓▓▄ ▄██▒▒██   ██░░▓█▄   ▌▒▓█  ▄ ▒██▀▀█▄  
    ░▒█░   ▒▒█████▓ ▒██████▒▒░██░░ ████▓▒░▒██░   ▓██░   ▒ ▓███▀ ░░ ████▓▒░░▒████▓ ░▒████▒░██▓ ▒██▒
     ▒ ░   ░▒▓▒ ▒ ▒ ▒ ▒▓▒ ▒ ░░▓  ░ ▒░▒░▒░ ░ ▒░   ▒ ▒    ░ ░▒ ▒  ░░ ▒░▒░▒░  ▒▒▓  ▒ ░░ ▒░ ░░ ▒▓ ░▒▓░
     ░     ░░▒░ ░ ░ ░ ░▒  ░ ░ ▒ ░  ░ ▒ ▒░ ░ ░░   ░ ▒░     ░  ▒     ░ ▒ ▒░  ░ ▒  ▒  ░ ░  ░  ░▒ ░ ▒░
     ░ ░    ░░░ ░ ░ ░  ░  ░   ▒ ░░ ░ ░ ▒     ░   ░ ░    ░        ░ ░ ░ ▒   ░ ░  ░    ░     ░░   ░ 
              ░           ░   ░      ░ ░           ░    ░ ░          ░ ░     ░       ░  ░   ░     
                                                        ░                  ░                      
    
                                                                                
Desenvolvido por: Fusion #EternoThiaga1
GitHub: https://github.com/fus10-n
Contato: fusi0ndev@proton.me
  `));
}

// Função para remover duplicatas
async function removeDuplicates(inputFilePath, outputFilePath) {
  const uniqueLines = new Set();

  const inputStream = fs.createReadStream(inputFilePath, { encoding: 'utf8' });
  const outputStream = fs.createWriteStream(outputFilePath, { encoding: 'utf8' });

  const rl = readline.createInterface({
    input: inputStream,
    crlfDelay: Infinity,
  });

  for await (const line of rl) {
    if (!uniqueLines.has(line)) {
      uniqueLines.add(line);
      outputStream.write(line + '\n');
    }
  }

  outputStream.end();
  console.log(chalk.green('Todas as duplicadas foram removidas do seu txt.'));
}

// Exibir créditos
printCredits();

// Defina os caminhos do arquivo de entrada e saída
const inputFilePath = path.join(process.cwd(), 'separar.txt'); // Caminho do arquivo original
const outputFilePath = path.join(process.cwd(), 'separadas.txt'); // Caminho para o novo arquivo sem duplicatas

removeDuplicates(inputFilePath, outputFilePath).catch(console.error);
